"""Hippocampal-MAPPO models."""
