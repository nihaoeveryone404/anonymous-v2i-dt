"""Hippocampal-MAPPO evaluation."""
