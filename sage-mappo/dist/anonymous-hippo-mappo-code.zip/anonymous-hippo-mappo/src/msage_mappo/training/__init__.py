"""Hippocampal-MAPPO training."""
