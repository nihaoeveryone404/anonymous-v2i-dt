"""Repository entry point for training.full."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from msage_mappo.training.full import main


if __name__ == "__main__":
    main()
